using System;

class Program
{
    static void Main(string[] args)
    {
        int i = 0;
        int[] idades = new int[60];
        int totalAlunos = 0;
        int somaIdades = 0;
      Random random = new Random();

        idades[i]= random.Next(0,60);
        Console.WriteLine($"idades dos alunos presentes na aula {i+1}: {idades[i]} (digite 0 para encerrar");
        for (i = 0; i < 60; i++)
        {
            int idade = Convert.ToInt32(Console.ReadLine());
            if (idade == 0)
                break;

            idades[i] = idade;
            totalAlunos++;
            somaIdades += idade;
        }

       
        double mediaIdades = (double)somaIdades / totalAlunos;

        
        Console.WriteLine("\nIdades dos alunos presentes na aula:");
        for (i = 0; i < totalAlunos; i++)
        {
            Console.WriteLine(idades[i]);
        }

        Console.WriteLine("\nIdades dos alunos com idade superior à média:");
        for (i = 0; i < totalAlunos; i++)
        {
            if (idades[i] > mediaIdades)
            {
                Console.WriteLine(idades[i]);
            }
        }
    }
}
